/**
 * @name ChipSquareBorder2
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMCIgaGVpZ2h0PSIzMyIgZmlsbD0iY3VycmVudENvbG9yIiB2aWV3Qm94PSIwIDAgMzAgMzMiPiAgPHBhdGggZD0iTTI0IDJhNCA0IDAgMCAxIDQgNHYxOGE0IDQgMCAwIDEtMiAzLjQ3bC04LjI1IDQuN2E0Ljk4IDQuOTggMCAwIDEtNS41IDBsLTguMTItNC42My0uMjMtLjE0QTQgNCAwIDAgMSAyIDI0VjZhNCA0IDAgMCAxIDQtNGgxOFoiLz4gIDxwYXRoIGZpbGw9IiNmZmYiIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTI0IDJhNCA0IDAgMCAxIDQgNHYxOGE0IDQgMCAwIDEtMiAzLjQ3bC04LjI1IDQuN2E0Ljk4IDQuOTggMCAwIDEtNS41IDBsLTguMTItNC42My0uMjMtLjE0QTQgNCAwIDAgMSAyIDI0VjZhNCA0IDAgMCAxIDQtNGgxOFpNNiA0YTIgMiAwIDAgMC0yIDJ2MThhMiAyIDAgMCAwIC45MyAxLjdsLjIuMSA4LjExIDQuNjQuMDYuMDMuMDUuMDRhMi45OCAyLjk4IDAgMCAwIDMuMyAwbC4wNS0uMDQuMDYtLjAzTDI1IDI1LjczQTIgMiAwIDAgMCAyNiAyNFY2YTIgMiAwIDAgMC0yLTJINloiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==)
 * @type {Array}
 */
export const ChipSquareBorder2 = [
  "svg",
  {
    xmlns: "http://www.w3.org/2000/svg",
    width: "30",
    height: "33",
    fill: "currentColor",
    viewBox: "0 0 30 33",
  },
  [
    [
      "path",
      {
        d: "M24 2a4 4 0 0 1 4 4v18a4 4 0 0 1-2 3.47l-8.25 4.7a4.98 4.98 0 0 1-5.5 0l-8.12-4.63-.23-.14A4 4 0 0 1 2 24V6a4 4 0 0 1 4-4h18Z",
      },
    ],
    [
      "path",
      {
        fill: "#fff",
        "fill-rule": "evenodd",
        d: "M24 2a4 4 0 0 1 4 4v18a4 4 0 0 1-2 3.47l-8.25 4.7a4.98 4.98 0 0 1-5.5 0l-8.12-4.63-.23-.14A4 4 0 0 1 2 24V6a4 4 0 0 1 4-4h18ZM6 4a2 2 0 0 0-2 2v18a2 2 0 0 0 .93 1.7l.2.1 8.11 4.64.06.03.05.04a2.98 2.98 0 0 0 3.3 0l.05-.04.06-.03L25 25.73A2 2 0 0 0 26 24V6a2 2 0 0 0-2-2H6Z",
        "clip-rule": "evenodd",
      },
    ],
  ],
];
